<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Top NID Coaching | Expert Prep for B.Des & M.Des Success</title>
    <meta name="google-site-verification" content="AB0a1cA4zkM4DXlhdMUKGc3V0GirLuXigfIYhtjd9Pk" />
    <meta name="title" content="Best NID Coaching for DAT & Studio Test | NID Preparation">
    <meta name="description" content="Get expert NID coaching for DAT Prelims, Mains & Studio Test. Join the best NID entrance preparation with online & offline classes. Enroll today!">
    <link rel="icon" href="images/brds.png" type="image/svg+xml">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" />
    <link rel="stylesheet" href="css/minified.css?v=3.1">
    <link rel="stylesheet" href="css/custom.css?v=<?php echo time(); ?>">
    <script src="js/jquery.min.js"></script>
    <script>
        jQuery(document).ready(function () {
            url = new URL(window.location.href);
            var campaign_name = url.searchParams.get("utm_campaign");
            var keyword = url.searchParams.get("utm_keyword");
            var source = url.searchParams.get("utm_source");
            var medium = url.searchParams.get("utm_medium");
            var network = url.searchParams.get("utm_network");
            document.getElementById("campaign_url").value = window.location.href;
            document.getElementById("campaign_name").value = campaign_name;
            document.getElementById("keyword").value = keyword;
            document.getElementById("sourceId").value = source;
            document.getElementById("mediumId").value = medium;
            document.getElementById("network").value = network;
            if (document.referrer) {
                var myReferer = document.referrer;
                document.getElementById("referrerid").value = myReferer;
            } else {
                document.getElementById("referrerid").value = 'None';
            }
        });
    </script>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-QF56WX8800"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());
        gtag('config', 'G-QF56WX8800');
    </script>
    <!-- Google Tag Manager -->
    <script>(function (w, d, s, l, i) {
        w[l] = w[l] || []; w[l].push({
            'gtm.start': new Date().getTime(), event: 'gtm.js'
        }); var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
            'https://www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-WSZX8D67');</script>
    <!-- End Google Tag Manager -->
    <style>
        /* Improved styles for better readability and spacing */
        body {
            font-family: 'Poppins', sans-serif;
            line-height: 1.6;
        }
        section {
            padding: 4rem 0;
        }
        .container {
            max-width: 1200px;
        }
        /* Accordion styles */
        .accordion-button:not(.collapsed) {
            background-color: #f8f9fa;
            color: #e31e24;
        }
        .accordion-button:focus {
            box-shadow: none;
            border-color: rgba(0,0,0,.125);
        }
        /* Improved card styles */
        .card {
            transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        footer a {
            color: #fff;
            text-decoration: underline;
            font-weight: 700;
        }
        .call-button-wrapper {
            position: fixed;
            z-index: 999;
        }
        .call-button {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 24px;
            background-color: #e31e24;
            color: white;
            text-decoration: none;
            border-radius: 50px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
        }
        .call-button:hover {
            background-color: #c41920;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
        }
        /* Desktop and Laptop styles */
        @media (min-width: 768px) {
            .call-button-wrapper {
                bottom: 30px;
                right: 30px;
            }
        }
        /* Mobile and Tablet styles */
        @media (max-width: 767px) {
            .call-button-wrapper {
                bottom: 0;
                left: 0;
                right: 0;
                background: white;
                padding: 10px;
                box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
            }
            .call-button {
                justify-content: center;
                border-radius: 8px;
            }
        }
    </style>
</head>
<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WSZX8D67" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
    <header>
        <div class="container-md">
            <div class="row align-items-center">
                <div class="col-md-6 col-12 p-0">
                    <div class="header-left"><img src="images/headerlogo.png" alt="headerlogo" class="headerlogo"></div>
                </div>
                <div class="col-md-6 col-12 header-right p-0">
                    <p class="p-right mb-0">India's No. 1 Design Coaching Institute</p>
                </div>
            </div>
        </div>
    </header>
    <section class="banner">
        <div class="container position-relative z-1">
            <div class="row gy-4 align-items-center">
                <div class="col-md-6 col-12">
                    <div class="banner-left text-center text-md-start">
                        <h2 class="text-white">NID Entrance Exam Coaching</h2>
                        <h3>Unlock a World of Design Excellence through NID Coaching with BRDS</h3>
                    </div>
                </div>
                <div class="col-md-6 col-12">
                    <div class="banner-right text-center mx-auto ms-lg-auto me-lg-0 mw-">
                        <h3>Admissions Open</h3>
                        <form method="post" action="brds_crm_api.php" enctype="multipart/form-data" id="brds_form">
    <div class="col-12">
        <input type="text" name="Name" class="form-control shadow-none border-0" id="name" 
            placeholder="Enter Name" required
            pattern="[A-Za-z\s]+" 
            title="Please enter only letters and spaces"
            onkeypress="return /[a-zA-Z\s]/i.test(event.key)">
    </div>
    <div class="col-12">
        <input type="tel" class="form-control shadow-none border-0" name="phone" 
            id="phone_number" placeholder="Enter Phone Number*" 
            maxlength="10" minlength="10" required
            pattern="[6-9][0-9]{9}"
            title="Please enter valid 10 digit mobile number starting with 6-9"
            onkeypress="return /[0-9]/i.test(event.key)">
    </div>
    <div class="col-12">
        <!-- Update the email input pattern -->
<input type="email" 
    class="form-control shadow-none border-0" 
    name="email" 
    id="email" 
    placeholder="Enter Email*" 
    required
    pattern="[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"
    title="Please enter a valid email address">
    </div>
                            <!--<div class="col-12">-->
                            <!--    <select class="form-select bn-form shadow-none border-0" aria-label="Default select" id="stateid" onchange="select_state_func()" data-errormessage-value-missing="* State is required!" name="state" required>-->
                            <!--        <option value="">Your State</option>-->
                            <!--         <option value="1">Andaman &amp; Nicobar Islands</option>-->
                            <!--        <option value="2">Andhra Pradesh</option>-->
                            <!--        <option value="3">Arunachal Pradesh</option>-->
                            <!--        <option value="4">Assam</option>-->
                            <!--        <option value="5">Bihar</option>-->
                            <!--        <option value="6">Chandigarh</option>-->
                            <!--        <option value="7">Chhattisgarh</option>-->
                            <!--        <option value="32">Dadra and Nagar Haveli</option>-->
                            <!--        <option value="33">Daman and Diu</option>-->
                            <!--        <option value="8">Delhi</option>-->
                            <!--         <option value="9">Goa</option>-->
                            <!--        <option value="10">Gujarat</option>-->
                            <!--        <option value="11">Haryana</option>-->
                            <!--         <option value="12">Himachal Pradesh</option>-->
                            <!--        <option value="13">Jammu and Kashmir</option>-->
                            <!--        <option value="14">Jharkhand</option>-->
                            <!--        <option value="15">Karnataka</option>-->
                            <!--        <option value="16">Kerala</option>-->
                            <!--        <option value="17">Madhya Pradesh</option>-->
                            <!--        <option value="18">Maharashtra</option>-->
                            <!--        <option value="19">Manipur</option>-->
                            <!--        <option value="20">Meghalaya</option>-->
                            <!--        <option value="21">Mizoram</option>-->
                            <!--        <option value="22">Nagaland</option>-->
                            <!--        <option value="23">Orissa</option>-->
                            <!--        <option value="24">Pondicherry</option>-->
                            <!--        <option value="25">Punjab</option>-->
                            <!--        <option value="26">Rajasthan</option>-->
                            <!--        <option value="34">Sikkim</option>-->
                            <!--        <option value="27">Tamil Nadu</option>-->
                            <!--        <option value="36">Telangana</option>-->
                            <!--        <option value="28">Tripura</option>-->
                            <!--        <option value="29">Uttar Pradesh</option>-->
                            <!--         <option value="30">Uttaranchal</option>-->
                            <!--        <option value="31">West Bengal</option>-->
                            <!--    </select>-->
                            <!--</div>-->
<!--                            <div class="col-12" id="citypid">-->
<!--    <select name="city" data-errormessage-value-missing="* City is required!" class="form-select bn-form formbg1 validate[required]" placeholder="City" id="cityid" required>-->
<!--        <option selected="selected" value="">Your City</option>-->
<!--</div>-->
<!-- Adding Qualification dropdown -->
                            <div class="col-12">
                                <select class="form-select bn-form shadow-none border-0" aria-label="Default select" id="qualificationId" name="qualification" required>
                                    <option value="">Select Qualification</option>
                                    <option value="IX">IX Std or Lower</option>
                                    <option value="X">X Std</option>
                                    <option value="XI">XI Std</option>
                                    <option value="XII">XII Std</option>
                                    <option value="UG">Under Graduate</option>
                                    <option value="G">Graduate</option>
                                </select>
                            </div>
                            <div class="col-12 ">
                                <input type="hidden" id="referrerid" name="referrer_name" value="" />
                                <input type="hidden" id="keyword" name="keyword" value="" />
                                <input type="hidden" id="network" name="network" value="" />
                                <input type="hidden" id="campaign_url" name="campaign_url" value="" />
                                <input type="hidden" id="campaign_name" name="campaign_name" value="<?php if (isset($_GET['utm_campaign'])) { echo $_GET['utm_campaign']; } ?>" />
                                <input type="hidden" id="sourceId" name="sourcemedium" value="<?php if (isset($_GET['utm_source'])) { echo $_GET['utm_source']; } ?>" />
                                <input type="hidden" id="mediumId" name="medium" value="<?php if (isset($_GET['utm_medium'])) { echo $_GET['utm_medium']; } ?>" />
                                <input type="hidden" name="orderid" value="1021" />
                                <input type="hidden" name="sitename" value="NIDCOACHING" />
                                <input type="submit" class="banner-form-btn" value="Apply Now" name="submit" />
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</head>
<body>
<div class="particles" id="particles"></div>
  
<div class="challenge_container_main">
  <div class="container challenge_container">
    <div class="challenge-card">
      <!-- Header Section -->
      <div class="challenge-header">
        
        <h2 class="challenge-title">BRDS Challenge</h2>
      </div>
      
      <!-- Main Content -->
      <div class="challenge-content">
        <p class="challenge-description">
          <span class="highlight">BRDS</span> is proud to announce that <span class="highlight">BRDS</span> has the highest selection of students in 
          <span class="badge">NID</span>
          <span class="badge">NIFT</span>
          <span class="badge">IIT-UCEED / CEED</span>
          <span class="badge">NATA</span>
          <span class="badge">CEPT</span>
          this year as compared to any coaching institute in India.
        </p>
        
        <div class="prize-statement">
          Avail Rs. 1 Crore prize money if you prove that any other coaching Institute has more results than BRDS.
        </div>
        
        <!-- Prize Highlight Section -->
        <div class="prize-highlight">
          <div class="confetti-container" id="confetti-container"></div>
          
          <div class="prize-amount-wrapper">
            <div class="prize-label-top">WIN UP TO</div>
            <div class="amount-container shine">
              <div class="amount-bg"></div>
              <div class="amount" id="prize-amount">₹1,00,00,000</div>
            </div>
            <div class="prize-label">
              <svg class="award-icon" viewBox="0 0 24 24" width="30" height="30" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="8" r="7"></circle>
                <polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"></polyline>
              </svg>
              <span>(1 Crore) Prize Challenge</span>
            </div>
          </div>
        </div>
        
        <!-- Challenge Button -->
        <div class="challenge-button-container">
          <button id="challenge-button" class="challenge-button">
            Take the Challenge
            <span class="arrow-icon">→</span>
          </button>
        </div>
        
       
      </div>
    </div>
  </div>
</div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      // Create particles
      const particlesContainer = document.getElementById('particles');
      const particleCount = 30;
      
      for (let i = 0; i < particleCount; i++) {
        const particle = document.createElement('div');
        particle.classList.add('particle');
        
        // Random properties
        const size = Math.random() * 4 + 2;
        const posX = Math.random() * 100;
        const duration = Math.random() * 10 + 10;
        const delay = Math.random() * 5;
        const opacity = Math.random() * 0.5 + 0.3;
        const scale = Math.random() * 0.6 + 0.4;
        
        // Set custom properties
        particle.style.setProperty('--duration', `${duration}s`);
        particle.style.setProperty('--opacity', opacity);
        particle.style.setProperty('--scale', scale);
        
        particle.style.width = `${size}px`;
        particle.style.height = `${size}px`;
        particle.style.left = `${posX}%`;
        particle.style.animationDelay = `${delay}s`;
        
        // Add gold shimmer effect
        particle.style.boxShadow = '0 0 10px rgba(255, 215, 0, 0.7)';
        
        particlesContainer.appendChild(particle);
      }
      
      // Prize amount counter animation
      const prizeAmount = document.getElementById('prize-amount');
      const finalAmount = 10000000; // 1 Crore in numbers
      let currentAmount = 0;
      const duration = 2000; // 2 seconds
      const frameRate = 60;
      const increment = finalAmount / (duration / 1000 * frameRate);
      
      function formatCurrency(amount) {
        return '₹' + amount.toLocaleString('en-IN');
      }
      
      function animateCounter() {
        if (currentAmount < finalAmount) {
          currentAmount += increment;
          if (currentAmount > finalAmount) {
            currentAmount = finalAmount;
          }
          prizeAmount.textContent = formatCurrency(Math.floor(currentAmount));
          requestAnimationFrame(animateCounter);
        } else {
          // Add the final formatted amount with commas in Indian format
          prizeAmount.textContent = '₹1,00,00,000';
          
          // Trigger confetti after counter completes
          createConfetti();
        }
      }
      
      // Start the animation after a short delay
      setTimeout(animateCounter, 500);
      
      // Challenge button effects
      const challengeButton = document.getElementById('challenge-button');
      
      challengeButton.addEventListener('mouseenter', function() {
        const arrowIcon = this.querySelector('.arrow-icon');
        arrowIcon.style.opacity = '1';
        arrowIcon.style.transform = 'translateX(0)';
      });
      
      challengeButton.addEventListener('mouseleave', function() {
        const arrowIcon = this.querySelector('.arrow-icon');
        arrowIcon.style.opacity = '0';
        arrowIcon.style.transform = 'translateX(-10px)';
      });
      
      // Add click effect with confetti burst
      challengeButton.addEventListener('click', function(event) {
        // Create ripple effect
        const ripple = document.createElement('span');
        ripple.style.position = 'absolute';
        ripple.style.borderRadius = '50%';
        ripple.style.backgroundColor = 'rgba(255, 255, 255, 0.7)';
        ripple.style.transform = 'scale(0)';
        ripple.style.animation = 'ripple 0.6s linear';
        ripple.style.pointerEvents = 'none';
        
        // Position the ripple where clicked
        const rect = this.getBoundingClientRect();
        const x = event.clientX - rect.left;
        const y = event.clientY - rect.top;
        
        ripple.style.width = `${Math.max(rect.width, rect.height) * 2}px`;
        ripple.style.height = `${Math.max(rect.width, rect.height) * 2}px`;
        ripple.style.left = `${x - Math.max(rect.width, rect.height)}px`;
        ripple.style.top = `${y - Math.max(rect.width, rect.height)}px`;
        
        this.appendChild(ripple);
        
        // Remove ripple after animation completes
        setTimeout(() => {
          ripple.remove();
        }, 600);
        
        // Burst confetti on click
        createConfetti();
        
        // You can add your challenge logic here
        console.log('Challenge accepted!');
      });
      
      // Confetti effect
      function createConfetti() {
        const confettiContainer = document.getElementById('confetti-container');
        confettiContainer.innerHTML = ''; // Clear previous confetti
        
        const colors = ['#ffd700', '#ff4d4d', '#f43f5e', '#fbbf24', '#ffffff'];
        const confettiCount = 100;
        
        for (let i = 0; i < confettiCount; i++) {
          const confetti = document.createElement('div');
          confetti.classList.add('confetti');
          
          // Random properties
          const size = Math.random() * 8 + 4;
          const color = colors[Math.floor(Math.random() * colors.length)];
          const posX = Math.random() * 100;
          const posY = Math.random() * 100;
          const rotation = Math.random() * 360;
          const duration = Math.random() * 2 + 1;
          const delay = Math.random() * 0.5;
          
          // Set styles
          confetti.style.width = `${size}px`;
          confetti.style.height = `${size}px`;
          confetti.style.backgroundColor = color;
          confetti.style.left = `${posX}%`;
          confetti.style.top = `${posY}%`;
          confetti.style.transform = `rotate(${rotation}deg)`;
          confetti.style.opacity = '0';
          
          // Set animation
          confetti.style.animation = `
            confetti-fall ${duration}s ease-in ${delay}s forwards,
            confetti-fade ${duration}s ease-in ${delay}s forwards
          `;
          
          // Add keyframes dynamically
          const style = document.createElement('style');
          style.textContent = `
            @keyframes confetti-fall {
              0% {
                transform: translateY(-10px) rotate(${rotation}deg);
                opacity: 1;
              }
              100% {
                transform: translateY(${Math.random() * 100 + 50}px) rotate(${rotation + Math.random() * 360}deg);
                opacity: 0;
              }
            }
            
            @keyframes confetti-fade {
              0% {
                opacity: 1;
              }
              100% {
                opacity: 0;
              }
            }
          `;
          document.head.appendChild(style);
          
          confettiContainer.appendChild(confetti);
        }
      }
      
      // Entry animation
      const card = document.querySelector('.challenge-card');
      card.style.opacity = '0';
      card.style.transform = 'translateY(30px)';
      
      setTimeout(() => {
        card.style.transition = 'all 0.8s cubic-bezier(0.22, 1, 0.36, 1)';
        card.style.opacity = '1';
        card.style.transform = 'translateY(0)';
      }, 300);
    });
  </script>
<section class="body_exam">
    <div class="container_exam">
        <!-- Decorative Elements -->
        <div class="decoration_exam decoration-1_exam"></div>
        <div class="decoration_exam decoration-2_exam"></div>
        <div class="decoration_exam decoration-3_exam"></div>
        
        <!-- Floating Icons -->
        <i class="fas fa-paint-brush floating-icon_exam icon-1_exam"></i>
        <i class="fas fa-pencil-ruler floating-icon_exam icon-2_exam"></i>
        <i class="fas fa-palette floating-icon_exam icon-3_exam"></i>
        
        <!-- Section Header -->
        <div class="section-header_exam fade-in_exam">
         
          <h2 class="section-title_exam">NID Entrance Coaching - Courses offered by BRDS</h2>
        </div>
        
        <!-- Courses Grid -->
        <div class="courses-grid_exam">

          <!-- Foundation Course -->
<div class="course-card_exam foundation_exam fade-in-up_exam" style="animation-delay: 0.1s;">
    <div class="course-header_exam shimmer_exam">
        <h3 class="course-title_exam">NID - Foundation Coaching</h3>
        <p class="course-subtitle_exam">(For students in Class 9th, 10th & 11th)</p>
    </div>
    <div class="course-content_exam">
        <!-- Option 1 -->
        <div class="course-option_exam">
            <h4 class="option-title_exam"><i class="fas fa-calendar-alt"></i> Option 1 - Regular/ Weekend Course</h4>
            <div class="option-details_exam">
                <div class="detail-item_exam">
                    <i class="fas fa-clock"></i>
                    <span>Duration: 1 year/ 6 months</span>
                </div>
                <div class="detail-item_exam">
                    <i class="fas fa-calendar-day"></i>
                    <span>Days: Weekend - Sat/Sun OR Weekdays (Any two days M to F)</span>
                </div>
            </div>
            <button class="read-more-btn_exam" data-course="foundation" data-option="regular">Read More <i class="fas fa-arrow-right"></i></button>
        </div>
        
        <!-- Option 2 (Hidden by default) -->
        <div class="course-option_exam option-2" style="display: none;">
            <h4 class="option-title_exam"><i class="fas fa-bolt"></i> Option 2 - Crash Course</h4>
            <div class="option-details_exam">
                <div class="detail-item_exam">
                    <i class="fas fa-clock"></i>
                    <span>Duration: 10 Days/ 14 Days/ 1 month</span>
                </div>
                <div class="detail-item_exam">
                    <i class="fas fa-calendar-day"></i>
                    <span>Days: Mon to Sat (6 Days a week)</span>
                </div>
            </div>
        </div>
    </div>
</div>
          
          <!-- B.Design Course -->
          <div class="course-card_exam bdesign_exam fade-in-up_exam" style="animation-delay: 0.3s;">
            <div class="course-header_exam shimmer_exam">
              <h3 class="course-title_exam">NID B.Design Coaching</h3>
              <p class="course-subtitle_exam">(For Students in Grade 12th & 12th Passed)</p>
            </div>
            <div class="course-content_exam">
              <!-- Option 1 -->
              <div class="course-option_exam">
                <h4 class="option-title_exam"><i class="fas fa-calendar-alt"></i> Option 1 - Regular/ Weekend Course</h4>
                <div class="option-details_exam">
                  <div class="detail-item_exam">
                    <i class="fas fa-clock"></i>
                    <span>Duration: 1 year/ 6 months</span>
                  </div>
                  <div class="detail-item_exam">
                    <i class="fas fa-calendar-day"></i>
                    <span>Days: Weekend - Sat & Sun OR Weekdays (Any two days M to F)</span>
                  </div>
                </div>
                <button class="read-more-btn_exam" data-course="bdesign" data-option="regular">Read More <i class="fas fa-arrow-right"></i></button>
              </div>
              
              <!-- Option 2 -->
              <div class="course-option_exam option-2" style="display: none;">
                <h4 class="option-title_exam"><i class="fas fa-bolt"></i> Option 2 - Crash Course</h4>
                <div class="option-details_exam">
                  <div class="detail-item_exam">
                    <i class="fas fa-clock"></i>
                    <span>Duration: 14 Days/ 1 month/ 2 Months</span>
                  </div>
                  <div class="detail-item_exam">
                    <i class="fas fa-calendar-day"></i>
                    <span>Days: Mon to Sat (6 Days a week) OR Mon to Fri (5 Days a week)</span>
                  </div>
                </div>
               
              </div>
            </div>
          </div>
          
          <!-- M.Design Course -->
          <div class="course-card_exam mdesign_exam fade-in-up_exam" style="animation-delay: 0.5s;">
            <div class="course-header_exam shimmer_exam">
              <h3 class="course-title_exam">NID M.Design Coaching</h3>
              <p class="course-subtitle_exam">(For Students Pursuing Graduation/ Graduates)</p>
            </div>
            <div class="course-content_exam">
              <!-- Option 1 -->
              <div class="course-option_exam">
                <h4 class="option-title_exam"><i class="fas fa-calendar-alt"></i> Option 1 - Regular/ Weekend Course</h4>
                <div class="option-details_exam">
                  <div class="detail-item_exam">
                    <i class="fas fa-clock"></i>
                    <span>Duration: 1 year/ 6 months</span>
                  </div>
                  <div class="detail-item_exam">
                    <i class="fas fa-calendar-day"></i>
                    <span>Days: Weekend - Sat & Sun OR Weekdays (Any two days M to F)</span>
                  </div>
                </div>
                <button class="read-more-btn_exam" data-course="mdesign" data-option="regular">Read More <i class="fas fa-arrow-right"></i></button>
              </div>
              
              <!-- Option 2 -->
              <div class="course-option_exam option-2" style="display: none;">
                <h4 class="option-title_exam"><i class="fas fa-bolt"></i> Option 2 - Crash Course</h4>
                <div class="option-details_exam">
                  <div class="detail-item_exam">
                    <i class="fas fa-clock"></i>
                    <span>Duration: 14 Days/ 1 month/ 2 Months</span>
                  </div>
                  <div class="detail-item_exam">
                    <i class="fas fa-calendar-day"></i>
                    <span>Days: Mon to Sat (6 Days a week) OR Mon to Fri (5 Days a week)</span>
                  </div>
                </div>
                
              </div>
            </div>
          </div>


<!-- DAT Mains Course -->
          <div class="course-card_exam dat-mains_exam fade-in-up_exam" style="animation-delay: 0.5s;">
            <div class="course-header_exam shimmer_exam">
              <h3 class="course-title_exam">NID DAT Mains (Studio Test) Coaching</h3>
              <p class="course-subtitle_exam">(B.Design / M.Design)</p>
            </div>
            <div class="course-content_exam">
              <div class="course-option_exam">
                <h4 class="option-title_exam">
                  <i class="fas fa-info-circle"></i>
                  <span>NID DAT Mains</span>
                </h4>
                <div class="option-details_exam">
                  <div class="detail-item_exam">
                    <i class="fas fa-clock"></i>
                    <span>Duration: 10 Days/ 14 Days/ 1 month</span>
                  </div>
                  <div class="detail-item_exam">
                    <i class="fas fa-calendar-day"></i>
                    <span>Days: Mon to Sat (6 Days a week)</span>
                  </div>
                </div>
               
              </div>
            </div>
          </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Get all read more buttons
    const readMoreButtons = document.querySelectorAll('.read-more-btn_exam');
    
    readMoreButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Find the parent course card
            const courseCard = this.closest('.course-card_exam');
            
            // Find the option 2 div within this card
            const option2 = courseCard.querySelector('.option-2');
            
            // Toggle option 2 visibility
            if (option2.style.display === 'none') {
                option2.style.display = 'block';
                this.innerHTML = 'Show Less <i class="fas fa-arrow-right"></i>';
            } else {
                option2.style.display = 'none';
                this.innerHTML = 'Read More <i class="fas fa-arrow-right"></i>';
            }
        });
    });
});
</script>
      
      <!-- Modal -->
      <div class="modal_exam" id="courseModal">
        <div class="modal-content_exam">
          <div class="modal-header_exam">
            <h3 class="modal-title_exam" id="modalTitle">Course Details</h3>
            <button class="close-modal_exam">&times;</button>
          </div>
          <div class="modal-body_exam" id="modalBody">
            <!-- Content will be dynamically inserted here -->
          </div>
          <div class="modal-footer_exam">
            <button class="enroll-btn_exam">Enroll Now</button>
          </div>
        </div>
      </div>
 </section>

    <section class="online_course_section">
    <div class="container">
    <div class="live-coaching-section_online">
      <!-- Section Header -->
      <div class="section-header_online">
        <h2 class="section-title_online">LIVE Online Coaching</h2>
      </div>
      
      <!-- Section Content -->
      <div class="section-content_online">
        <p class="intro-text_online fade-in_online">
          <span class="highlight_online">BRDS</span> provides two options for <span class="highlight_online">LIVE Online Coaching</span> to help you prepare for top design entrance exams:
        </p>
        
        <!-- Institutes Bar -->
        <div class="institutes-bar_online fade-in_online">
          <span class="institute_online">NID</span>
          <span>|</span>
          <span class="institute_online">NIFT</span>
          <span>|</span>
          <span class="institute_online">UCEED</span>
          <span>|</span>
          <span class="institute_online">CEED</span>
        </div>
        
        <!-- Options -->
        <div class="options-container_online">
          <div class="option_online fade-in-left_online" style="animation-delay: 0.2s;">
            <span class="option-number_online">Option 1:</span>
            <span class="option-text_online">LIVE Online Coaching ( Regular / Weekend Course )</span>
          </div>
          
          <div class="option_online fade-in-left_online" style="animation-delay: 0.4s;">
            <span class="option-number_online">Option 2:</span>
            <span class="option-text_online">LIVE Online Coaching – 14 Days / 28 Days / 2 Months Crash Course</span>
          </div>
        </div>
        
        <!-- Features Grid -->
        <div class="features-grid_online">
          <!-- Feature 1 -->
          <div class="feature-card_online yellow fade-in-up_online" style="animation-delay: 0.3s;">
            <div class="feature-header_online">
              Live Classes by our Expert Faculties
            </div>
            <div class="feature-image-container_online">
              <img class="feature-image_online" src="https://rathoredesign.com/wp-content/uploads/2022/06/Live-Classes.jpg" alt="Live Classes">
              <div class="feature-overlay_online">
                <div class="feature-detail_online">
                  <div class="feature-icon_online">✓</div>
                  <div>Interactive sessions with real-time feedback</div>
                </div>
                <div class="feature-detail_online">
                  <div class="feature-icon_online">✓</div>
                  <div>Learn from industry professionals and alumni</div>
                </div>
                <div class="feature-detail_online">
                  <div class="feature-icon_online">✓</div>
                  <div>Engaging demonstrations and tutorials</div>
                </div>
              </div>
            </div>
          </div>
          
          <!-- Feature 2 -->
          <div class="feature-card_online green fade-in-up_online" style="animation-delay: 0.5s;">
            <div class="feature-header_online">
              Personalized feedback on all student queries
            </div>
            <div class="feature-image-container_online">
              <img class="feature-image_online" src="https://rathoredesign.com/wp-content/uploads/2022/06/Personalized-feedback.png" alt="Personalized Feedback">
              <div class="feature-overlay_online">
                <div class="feature-detail_online">
                  <div class="feature-icon_online">✓</div>
                  <div>One-on-one doubt clearing sessions</div>
                </div>
                <div class="feature-detail_online">
                  <div class="feature-icon_online">✓</div>
                  <div>Detailed assessment of your work</div>
                </div>
                <div class="feature-detail_online">
                  <div class="feature-icon_online">✓</div>
                  <div>Personalized improvement strategies</div>
                </div>
              </div>
            </div>
          </div>
          
          <!-- Feature 3 -->
          <div class="feature-card_online blue fade-in-up_online" style="animation-delay: 0.7s;">
            <div class="feature-header_online">
              Assignments Solving Sessions
            </div>
            <div class="feature-image-container_online">
              <img class="feature-image_online" src="https://rathoredesign.com/wp-content/uploads/2020/04/Assignments-Solving-Sessions.png" alt="Assignment Sessions">
              <div class="feature-overlay_online">
                <div class="feature-detail_online">
                  <div class="feature-icon_online">✓</div>
                  <div>Guided practice with expert supervision</div>
                </div>
                <div class="feature-detail_online">
                  <div class="feature-icon_online">✓</div>
                  <div>Learn time management techniques</div>
                </div>
                <div class="feature-detail_online">
                  <div class="feature-icon_online">✓</div>
                  <div>Master problem-solving approaches</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <!-- Demo Registration -->
        <div class="demo-registration_online fade-in_online">
          <div class="demo-content_online">
            <div class="demo-title_online">
              <div class="live-icon_online">
                LIVE
                <div class="animated-dots_online">
                  <div class="dot_online"></div>
                  <div class="dot_online"></div>
                  <div class="dot_online"></div>
                </div>
              </div>
              Register for LIVE Demo Class
            </div>
            <div class="demo-text_online">
              Experience our teaching methodology and interactive platform with a free demo class
            </div>
            <div class="demo-contact_online">
              <a href="tel:9825057598" class="phone-number_online">98250 57598</a>
              <a href="#" class="register-button_online">Register Now</a>
            </div>
          </div>
          <div class="demo-image_online floating_online">
            <img src="https://stealthlearn.in/brds-new/wp-content/uploads/2024/12/brds-logo-cropped.svg" alt="Live Demo">
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      // Existing intersection observer code
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.style.visibility = 'visible';
          }
        });
      }, { threshold: 0.1 });
      
      // Existing observer code
      document.querySelectorAll('.fade-in, .fade-in-up, .fade-in-left, .fade-in-right').forEach(el => {
        el.style.visibility = 'hidden';
        observer.observe(el);
      });

      // ADD THIS NEW CODE HERE - Course Options Toggle
      const readMoreButtons = document.querySelectorAll('.read-more-btn_exam[data-option="regular"]');
    
      readMoreButtons.forEach(button => {
          button.addEventListener('click', function(e) {
              e.preventDefault();
              
              // Find the parent course card
              const courseCard = this.closest('.course-card_exam');
              
              // Find Option 2 within this course card
              const option2 = courseCard.querySelector('.course-option_exam:nth-child(2)');
              
              // Toggle Option 2 visibility
              option2.classList.toggle('show');
              
              // Toggle active state of button
              this.classList.toggle('active');
              
              // Change button text based on state
              if (this.classList.contains('active')) {
                  this.innerHTML = 'Show Less <i class="fas fa-arrow-right"></i>';
              } else {
                  this.innerHTML = 'Read More <i class="fas fa-arrow-right"></i>';
              }
          });
      });

      // Rest of your existing code...
      // Add hover effect to feature cards
      const featureCards = document.querySelectorAll('.feature-card');
      
      featureCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
          this.classList.add('glow');
        });
        
        card.addEventListener('mouseleave', function() {
          this.classList.remove('glow');
        });
      });
      
      // ... rest of your existing code ...
    });
  </script>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      // Add hover effect to course cards
      const courseCards = document.querySelectorAll('.course-card');
      
      courseCards.forEach(card => {
        // Reset animation when card is in view
        const observer = new IntersectionObserver((entries) => {
          entries.forEach(entry => {
            if (entry.isIntersecting) {
              const features = card.querySelectorAll('.feature-item');
              features.forEach(feature => {
                feature.style.animation = 'none';
                setTimeout(() => {
                  feature.style.animation = '';
                }, 10);
              });
            }
          });
        }, { threshold: 0.1 });
        
        observer.observe(card);
        
        // Add click event to read more buttons
        const readMoreBtn = card.querySelector('.read-more-btn');
        readMoreBtn.addEventListener('click', function() {
          // Create a modal effect
          const modal = document.createElement('div');
          modal.style.position = 'fixed';
          modal.style.top = '0';
          modal.style.left = '0';
          modal.style.width = '100%';
          modal.style.height = '100%';
          modal.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
          modal.style.display = 'flex';
          modal.style.alignItems = 'center';
          modal.style.justifyContent = 'center';
          modal.style.zIndex = '1000';
          modal.style.opacity = '0';
          modal.style.transition = 'opacity 0.3s ease';
          
          const modalContent = document.createElement('div');
          modalContent.style.backgroundColor = '#fff';
          modalContent.style.borderRadius = '10px';
          modalContent.style.padding = '30px';
          modalContent.style.maxWidth = '600px';
          modalContent.style.width = '90%';
          modalContent.style.maxHeight = '80vh';
          modalContent.style.overflow = 'auto';
          modalContent.style.transform = 'translateY(20px)';
          modalContent.style.transition = 'transform 0.3s ease';
          
          const closeBtn = document.createElement('button');
          closeBtn.textContent = '×';
          closeBtn.style.position = 'absolute';
          closeBtn.style.top = '10px';
          closeBtn.style.right = '15px';
          closeBtn.style.border = 'none';
          closeBtn.style.background = 'none';
          closeBtn.style.fontSize = '24px';
          closeBtn.style.cursor = 'pointer';
          closeBtn.style.color = '#333';
          
          const title = document.createElement('h2');
          title.textContent = card.querySelector('.course-title').textContent;
          title.style.marginBottom = '20px';
          title.style.color = card.classList.contains('crash-course') ? '#ffcc00' : '#ff3e3e';
          title.style.borderBottom = '2px solid ' + (card.classList.contains('crash-course') ? '#ffcc00' : '#ff3e3e');
          title.style.paddingBottom = '10px';
          
          const description = document.createElement('div');
          
          // Different content based on course type
          if (card.id === 'weekend-course') {
            description.innerHTML = `
              <p>Our Weekend/Regular Course is designed for students who want to balance their regular studies with design entrance exam preparation. This comprehensive program covers all aspects of NID, NIFT, IIT-UCEED, and CEED entrance exams.</p>
              <h3 style="margin: 15px 0 10px; color: #ff3e3e;">Course Highlights:</h3>
              <ul style="list-style-type: disc; margin-left: 20px; line-height: 1.6;">
                <li>Weekend classes to accommodate school/college schedules</li>
                <li>Comprehensive coverage of all design entrance exams</li>
                <li>Personal mentorship from NID, NIFT, and IIT alumni</li>
                <li>Regular mock tests and assessments</li>
                <li>Portfolio development guidance</li>
                <li>Interview preparation</li>
              </ul>
              <h3 style="margin: 15px 0 10px; color: #ff3e3e;">Course Duration:</h3>
              <p>6 months with weekend classes (Saturday and Sunday)</p>
              <h3 style="margin: 15px 0 10px; color: #ff3e3e;">Who Should Enroll:</h3>
              <p>Students in 11th, 12th, or graduates who want to prepare for design entrance exams while continuing their regular studies.</p>
            `;
          } else if (card.id === 'crash-course') {
            description.innerHTML = `
              <p>Our Crash Course is an intensive program designed for students who need to prepare quickly for upcoming design entrance exams. This focused course covers all essential topics and test-taking strategies.</p>
              <h3 style="margin: 15px 0 10px; color: #ffcc00;">Course Highlights:</h3>
              <ul style="list-style-type: disc; margin-left: 20px; line-height: 1.6;">
                <li>Intensive daily sessions</li>
                <li>Focus on high-yield topics and question patterns</li>
                <li>Strategic approach to maximize scores</li>
                <li>Daily practice sessions and assignments</li>
                <li>Personalized feedback on progress</li>
                <li>Last-minute tips and tricks</li>
              </ul>
              <h3 style="margin: 15px 0 10px; color: #ffcc00;">Course Duration:</h3>
              <p>1-2 months of intensive daily training</p>
              <h3 style="margin: 15px 0 10px; color: #ffcc00;">Who Should Enroll:</h3>
              <p>Students who have limited time before exams or need a refresher course to boost their preparation.</p>
            `;
          } else if (card.id === 'fast-track') {
            description.innerHTML = `
              <p>Our Fast Track Course is designed for serious aspirants who want accelerated preparation with focused guidance. This program ensures comprehensive coverage with optimized time management.</p>
              <h3 style="margin: 15px 0 10px; color: #ff3e3e;">Course Highlights:</h3>
              <ul style="list-style-type: disc; margin-left: 20px; line-height: 1.6;">
                <li>Accelerated learning path</li>
                <li>Strategic coverage of all important topics</li>
                <li>Regular assessments and performance tracking</li>
                <li>Specialized workshops for creative thinking</li>
                <li>One-on-one mentoring sessions</li>
                <li>Mock interviews and portfolio reviews</li>
              </ul>
              <h3 style="margin: 15px 0 10px; color: #ff3e3e;">Course Duration:</h3>
              <p>3-4 months of structured training</p>
              <h3 style="margin: 15px 0 10px; color: #ff3e3e;">Who Should Enroll:</h3>
              <p>Students who want a balanced approach between the comprehensive Regular Course and the intensive Crash Course.</p>
            `;
          }
          
          const enrollBtn = document.createElement('button');
          enrollBtn.textContent = 'Enroll Now';
          enrollBtn.style.backgroundColor = card.classList.contains('crash-course') ? '#ffcc00' : '#ff3e3e';
          enrollBtn.style.color = card.classList.contains('crash-course') ? '#333' : '#fff';
          enrollBtn.style.border = 'none';
          enrollBtn.style.padding = '12px 30px';
          enrollBtn.style.borderRadius = '30px';
          enrollBtn.style.marginTop = '20px';
          enrollBtn.style.cursor = 'pointer';
          enrollBtn.style.fontWeight = 'bold';
          enrollBtn.style.display = 'block';
          enrollBtn.style.width = '100%';
          
          modalContent.appendChild(closeBtn);
          modalContent.appendChild(title);
          modalContent.appendChild(description);
          modalContent.appendChild(enrollBtn);
          modal.appendChild(modalContent);
          document.body.appendChild(modal);
          
          // Animation
          setTimeout(() => {
            modal.style.opacity = '1';
            modalContent.style.transform = 'translateY(0)';
          }, 10);
          
          // Close modal
          closeBtn.addEventListener('click', function() {
            modal.style.opacity = '0';
            modalContent.style.transform = 'translateY(20px)';
            setTimeout(() => {
              document.body.removeChild(modal);
            }, 300);
          });
          
          // Close on outside click
          modal.addEventListener('click', function(e) {
            if (e.target === modal) {
              modal.style.opacity = '0';
              modalContent.style.transform = 'translateY(20px)';
              setTimeout(() => {
                document.body.removeChild(modal);
              }, 300);
            }
          });
          
          // Enroll button action
          enrollBtn.addEventListener('click', function() {
            alert('Thank you for your interest! Our team will contact you shortly with enrollment details.');
            modal.style.opacity = '0';
            modalContent.style.transform = 'translateY(20px)';
            setTimeout(() => {
              document.body.removeChild(modal);
            }, 300);
          });
        });
      });
      
      // Add subtle parallax effect to card headers
      document.addEventListener('mousemove', function(e) {
        const cards = document.querySelectorAll('.card-header');
        
        cards.forEach(card => {
          const rect = card.getBoundingClientRect();
          const x = e.clientX - rect.left;
          const y = e.clientY - rect.top;
          
          if (x > 0 && x < rect.width && y > 0 && y < rect.height) {
            const xPercent = (x / rect.width - 0.5) * 10;
            const yPercent = (y / rect.height - 0.5) * 10;
            
            card.querySelector('img').style.transform = `scale(1.05) translate(${xPercent}px, ${yPercent}px)`;
          } else {
            card.querySelector('img').style.transform = 'scale(1)';
          }
        });
      });
    });
  </script>

  <section>
  <div class="nid_result_container">
    <h2 class="nid_result_title nid_result_fade_in">BRDS NID 2024 Results</h2>
    
    <div class="nid_result_grid">
      <!-- Card 1 -->
      <div class="nid_result_card nid_result_fade_in" style="animation-delay: 0.1s;">
        <div class="nid_result_number nid_result_red">449</div>
        <div class="nid_result_content">
          <div class="nid_result_text">BRDS Students Qualified in NID 2024</div>
        </div>
      </div>
      
      <!-- Card 2 -->
      <div class="nid_result_card nid_result_fade_in" style="animation-delay: 0.2s;">
        <div class="nid_result_number nid_result_red">262</div>
        <div class="nid_result_content">
          <div class="nid_result_text">BRDS Students Selected in NID 2024 Final Selections (B. Design & M. Design)</div>
        </div>
      </div>
      
      <!-- Card 3 -->
      <div class="nid_result_card nid_result_fade_in" style="animation-delay: 0.3s;">
        <div class="nid_result_number nid_result_black">219</div>
        <div class="nid_result_content">
          <div class="nid_result_text">BRDS Students Selected in NID 2024 Final Selections (B.Design)</div>
        </div>
      </div>
      
      <!-- Card 4 -->
      <div class="nid_result_card nid_result_fade_in" style="animation-delay: 0.4s;">
        <div class="nid_result_number nid_result_black">43</div>
        <div class="nid_result_content">
          <div class="nid_result_text">BRDS Students Selected in NID 2024 Final Selections (M. Design)</div>
        </div>
      </div>
    </div>
  </div>
  </section>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      // Intersection Observer for animations
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.style.visibility = 'visible';
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
          }
        });
      }, { threshold: 0.1 });
      
      // Observe all animated elements
      document.querySelectorAll('.nid_result_fade_in').forEach(el => {
        el.style.visibility = 'hidden';
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
        
        observer.observe(el);
      });
      
      // Add hover effects to cards
      const resultCards = document.querySelectorAll('.nid_result_card');
      
      resultCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
          this.style.transform = 'translateY(-10px)';
          this.style.boxShadow = '0 15px 40px rgba(0, 0, 0, 0.15)';
        });
        
        card.addEventListener('mouseleave', function() {
          this.style.transform = 'translateY(0)';
          this.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.1)';
        });
      });
    });
  </script>

  <section style="display: flex; justify-content: center; align-items: center;">
  
    <img style="width: 70%;" class="nid_study_img" src="https://rathoredesign.com/wp-content/uploads/2022/08/nid-study.jpeg" alt="NID Tab Background">
  </section>
<section>
<div class="nid_tab_section">
    <div class="nid_tab_container">
      <!-- Section Header -->
      <div class="nid_tab_section_header nid_tab_fade_in">
        
        <h2 class="nid_tab_section_title">Important Information about NID</h2>
      </div>
      
      <!-- Tabs Container -->
      <div class="nid_tab_tabs_container nid_tab_fade_in_up">
        <div class="nid_tab_tabs_header" id="nidTabsHeader">
          <div class="nid_tab_tab active" data-tab="about"><i class="fas fa-info-circle"></i>About NID</div>
          <div class="nid_tab_tab" data-tab="date"><i class="fas fa-calendar-alt"></i>Date</div>
          <div class="nid_tab_tab" data-tab="pattern"><i class="fas fa-clipboard-list"></i>Pattern</div>
          <div class="nid_tab_tab" data-tab="application"><i class="fas fa-file-alt"></i>Application</div>
          <div class="nid_tab_tab" data-tab="cutoff"><i class="fas fa-chart-line"></i>Cut Off</div>
          <div class="nid_tab_tab" data-tab="result"><i class="fas fa-trophy"></i>Results</div>
        </div>
        
        <div class="nid_tab_tabs_content">
          <!-- Floating particles -->
          <div class="nid_tab_particles" id="nidParticles"></div>
          
          <!-- About NID Tab -->
          <div class="nid_tab_tab_pane active" id="about">
            <h3 class="nid_tab_tab_title">About National Institute of Design</h3>
            <p class="nid_tab_tab_description">
              <span class="nid_tab_highlight">National Institute of Design (NID)</span> is recognized globally as the top educational and research institute for pursuing Bachelor and Master's programs in Communication, Industrial, IT Integrated (Experiential), Interdisciplinary and Textile Design. The institute is empowered to award its own degrees and presently offers Bachelor of Design(B.Des.), Master of Design (M.Des.) and Doctor of Philosophy (PhD) in Design.
            </p>
          </div>
          
          <!-- Date Tab -->
          <div class="nid_tab_tab_pane" id="date">
            <h3 class="nid_tab_tab_title">Important Dates for NID Admission 2025-26</h3>
            
            <div class="nid_tab_info_table_wrapper">
              <table class="nid_tab_info_table">
                <thead>
                  <tr>
                    <th>Event</th>
                    <th>B.Des</th>
                    <th>M.Des</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><strong>NID DAT Prelims Exam</strong></td>
                    <td>05 Jan 2025</td>
                    <td>05 Jan 2025</td>
                  </tr>
                  <tr>
                    <td><strong>NID DAT Prelims Result</strong></td>
                    <td>01 Apr 2025</td>
                    <td>17 Feb 2025</td>
                  </tr>
                  <tr>
                    <td><strong>NID DAT Mains Exam</strong></td>
                    <td>26 Apr 2025 to 04 May 2025</td>
                    <td>3 March 2025 to 06 April 2025</td>
                  </tr>
                  <tr>
                    <td><strong>NID DAT Mains Result</strong></td>
                    <td>16 May 2025</td>
                    <td>06 May 2025</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          
          <!-- Pattern Tab -->
          <div class="nid_tab_tab_pane" id="pattern">
            <h3 class="nid_tab_tab_title">NID Entrance Exam Pattern</h3>
            <p class="nid_tab_tab_description">
              The NID entrance examination is conducted in two stages: Preliminary Examination (DAT Prelims) and Mains Examination (DAT Mains). Understanding the exam pattern is crucial for effective preparation.
            </p>
            
            <div class="nid_tab_info_card nid_tab_fade_in_left">
              <h4 class="nid_tab_info_card_title"><i class="fas fa-graduation-cap"></i>NID DAT Examination Structure</h4>
              <ul class="nid_tab_info_list">
                <li><strong>Stage 1: NID DAT Prelims</strong> - Pen & Paper based Written Test</li>
                <li><strong>Stage 2: NID DAT Mains</strong> - Studio Test</li>
              </ul>
             
            </div>
          </div>
        
          <!-- Application Form Tab -->
          <div class="nid_tab_tab_pane" id="application">
            <h3 class="nid_tab_tab_title">NID 2025 Application Form</h3>
            <p class="nid_tab_tab_description">
              The application process for NID 2025 is completely online. Visit the official NID admissions website to apply.
            </p>
            
            <div class="nid_tab_info_card nid_tab_shimmer">
              <h4 class="nid_tab_info_card_title"><i class="fas fa-exclamation-circle"></i> Important Note</h4>
              <p>Applications for NID 2025 will open in September 2024. Keep checking the official website for updates. BRDS helps you prepare a flawless application to maximize your chances of selection.</p>
            </div>
            
            <div style="text-align: center; margin-top: 30px;">
              <a href="https://admissions.nid.edu" target="_blank" class="nid_tab_register_btn">
                <i class="fas fa-user-plus"></i> Register Now
              </a>
            </div>
          </div>
          
          <!-- Cut Off Tab -->
          <div class="nid_tab_tab_pane" id="cutoff">
            <h3 class="nid_tab_tab_title">NID Cut off for Admissions 2024 – 2025</h3>
            <p class="nid_tab_tab_description">
              All candidates need to meet NID DAT cutoff in order to secure admission in design courses offered at National Institute of Design (NID). Understanding these cutoffs is essential for setting realistic goals in your preparation journey.
            </p>
            
            <h4 class="nid_tab_tab_title">NID Minimum Qualifying Criteria</h4>
            <div class="nid_tab_info_table_wrapper">
              <table class="nid_tab_info_table">
                <thead>
                  <tr>
                    <th>Programme</th>
                    <th>Open</th>
                    <th colspan="5">Reserved Categories</th>
                  </tr>
                  <tr>
                    <th></th>
                    <th></th>
                    <th>EWS</th>
                    <th>OBC-NCL</th>
                    <th>SC</th>
                    <th>ST</th>
                    <th>PwD</th>
                    <th>Overseas</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>B.Des</td>
                    <td>50</td>
                    <td>50</td>
                    <td>45</td>
                    <td>40</td>
                    <td>40</td>
                    <td>40</td>
                    <td>50</td>
                  </tr>
                  <tr>
                    <td>M.Des</td>
                    <td>50</td>
                    <td>50</td>
                    <td>45</td>
                    <td>40</td>
                    <td>40</td>
                    <td>40</td>
                    <td>50</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          
          <!-- Result Tab -->
          <div class="nid_tab_tab_pane" id="result">
            <h3 class="nid_tab_tab_title">About NID Result</h3>
            <p class="nid_tab_tab_description">
              The NID Results 2025 will be declared through online mode only. The scorecard is considered valid for the current year only. The candidate needs to log in to the official website and enter their registered details to check their result of NID. The scorecard will include all relevant information, including the qualifying status.
            </p>
            
            <div class="nid_tab_info_card nid_tab_shimmer">
              <h4 class="nid_tab_info_card_title"><i class="fas fa-medal"></i> BRDS Success Story</h4>
              <p>BRDS has consistently produced outstanding results in NID admissions. Our specialized coaching methodology, expert faculty, and comprehensive study materials have helped hundreds of students realize their dreams of studying at NID.</p>
            </div>
            
            <h4 class="nid_tab_tab_title">BRDS NID 2024 Results</h4>
            <div class="nid_tab_stats_grid">
              <div class="nid_tab_stats_card nid_tab_fade_in_up" style="animation-delay: 0.1s;">
                <div class="nid_tab_stats_header">449</div>
                <div class="nid_tab_stats_content">
                  <div class="nid_tab_stats_label">BRDS Students Qualified in NID 2024</div>
                </div>
              </div>
              
              <div class="nid_tab_stats_card nid_tab_fade_in_up" style="animation-delay: 0.2s;">
                <div class="nid_tab_stats_header black">219</div>
                <div class="nid_tab_stats_content">
                  <div class="nid_tab_stats_label">BRDS Students Selected in NID 2024 Final Selections (B.Design)</div>
                </div>
              </div>
              
              <div class="nid_tab_stats_card nid_tab_fade_in_up" style="animation-delay: 0.3s;">
                <div class="nid_tab_stats_header">262</div>
                <div class="nid_tab_stats_content">
                  <div class="nid_tab_stats_label">BRDS Students Selected in NID 2024 Final Selections (B. Design & M. Design)</div>
                </div>
              </div>
              
              <div class="nid_tab_stats_card nid_tab_fade_in_up" style="animation-delay: 0.4s;">
                <div class="nid_tab_stats_header black">43</div>
                <div class="nid_tab_stats_content">
                  <div class="nid_tab_stats_label">BRDS Students Selected in NID 2024 Final Selections (M. Design)</div>
                  <a href="#" class="nid_tab_read_more">Read More</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </section>
  
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      // Tabs functionality
      const tabs = document.querySelectorAll('.nid_tab_tab');
      const tabPanes = document.querySelectorAll('.nid_tab_tab_pane');
      const tabsHeader = document.getElementById('nidTabsHeader');
      
      tabs.forEach(tab => {
        tab.addEventListener('click', function() {
          // Remove active class from all tabs and tab panes
          tabs.forEach(t => t.classList.remove('active'));
          tabPanes.forEach(p => p.classList.remove('active'));
          
          // Add active class to clicked tab
          this.classList.add('active');
          
          // Show corresponding tab pane
          const tabId = this.getAttribute('data-tab');
          document.getElementById(tabId).classList.add('active');
          
          // Scroll tab into view if needed
          const tabRect = this.getBoundingClientRect();
          const headerRect = tabsHeader.getBoundingClientRect();
          
          if (tabRect.left < headerRect.left) {
            tabsHeader.scrollLeft += tabRect.left - headerRect.left - 20;
          } else if (tabRect.right > headerRect.right) {
            tabsHeader.scrollLeft += tabRect.right - headerRect.right + 20;
          }
        });
      });
      
      // Intersection Observer for animations
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.style.visibility = 'visible';
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
          }
        });
      }, { threshold: 0.1 });
      
      // Observe all animated elements
      document.querySelectorAll('.nid_tab_fade_in, .nid_tab_fade_in_up, .nid_tab_fade_in_left, .nid_tab_fade_in_right').forEach(el => {
        el.style.visibility = 'hidden';
        el.style.opacity = '0';
        el.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
        
        if (el.classList.contains('nid_tab_fade_in_up')) {
          el.style.transform = 'translateY(30px)';
        } else if (el.classList.contains('nid_tab_fade_in_left')) {
          el.style.transform = 'translateX(-30px)';
        } else if (el.classList.contains('nid_tab_fade_in_right')) {
          el.style.transform = 'translateX(30px)';
        }
        
        observer.observe(el);
      });
      
      // Add hover effects to cards
      const infoCards = document.querySelectorAll('.nid_tab_info_card');
      
      infoCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
          this.style.transform = 'translateY(-8px)';
          this.style.boxShadow = '0 15px 30px rgba(0, 0, 0, 0.1)';
        });
        
        card.addEventListener('mouseleave', function() {
          this.style.transform = 'translateY(0)';
          this.style.boxShadow = '0 10px 20px rgba(0, 0, 0, 0.05)';
        });
      });
      
      // Create floating particles
      const particlesContainer = document.getElementById('nidParticles');
      const particleCount = 20;
      
      for (let i = 0; i < particleCount; i++) {
        createParticle(particlesContainer);
      }
      
      function createParticle(container) {
        const particle = document.createElement('span');
        particle.className = 'nid_tab_particle';
        
        // Random size between 5px and 20px
        const size = Math.random() * 15 + 5;
        particle.style.width = `${size}px`;
        particle.style.height = `${size}px`;
        
        // Random position
        particle.style.top = `${Math.random() * 100}%`;
        particle.style.left = `${Math.random() * 100}%`;
        
        // Random opacity
        particle.style.opacity = Math.random() * 0.5 + 0.1;
        
        // Animation
        const duration = Math.random() * 20 + 10;
        const delay = Math.random() * 5;
        
        particle.style.animation = `nid_tab_float ${duration}s ease-in-out ${delay}s infinite`;
        
        // Add keyframes if not already added
        if (!document.querySelector('#float-animation')) {
          const style = document.createElement('style');
          style.id = 'float-animation';
          style.textContent = `
            @keyframes nid_tab_float {
              0%, 100% {
                transform: translateY(0) translateX(0);
              }
              25% {
                transform: translateY(-30px) translateX(15px);
              }
              50% {
                transform: translateY(-15px) translateX(-15px);
              }
              75% {
                transform: translateY(-25px) translateX(5px);
              }
            }
          `;
          document.head.appendChild(style);
        }
        
        container.appendChild(particle);
      }
      
      // Adjust tab pane height based on content
      function adjustTabPaneHeight() {
        const activePane = document.querySelector('.nid_tab_tab_pane.active');
        if (activePane) {
          const tabsContent = document.querySelector('.nid_tab_tabs_content');
          tabsContent.style.minHeight = `${activePane.offsetHeight}px`;
        }
      }
      
      // Call initially and on window resize
      adjustTabPaneHeight();
      window.addEventListener('resize', adjustTabPaneHeight);
      
      // Call when tab is changed
      tabs.forEach(tab => {
        tab.addEventListener('click', function() {
          setTimeout(adjustTabPaneHeight, 100);
        });
      });
      
      // Add ripple effect to buttons
      const buttons = document.querySelectorAll('.nid_tab_register_btn');
      
      buttons.forEach(button => {
        button.addEventListener('click', function(e) {
          const x = e.clientX - e.target.getBoundingClientRect().left;
          const y = e.clientY - e.target.getBoundingClientRect().top;
          
          const ripple = document.createElement('span');
          ripple.style.position = 'absolute';
          ripple.style.width = '1px';
          ripple.style.height = '1px';
          ripple.style.borderRadius = '50%';
          ripple.style.backgroundColor = 'rgba(255, 255, 255, 0.7)';
          ripple.style.transform = 'scale(0)';
          ripple.style.left = x + 'px';
          ripple.style.top = y + 'px';
          ripple.style.animation = 'nid_tab_ripple 0.6s linear';
          
          this.appendChild(ripple);
          
          setTimeout(() => {
            ripple.remove();
          }, 600);
        });
      });
      
      // Add ripple animation if not already added
      if (!document.querySelector('#ripple-animation')) {
        const style = document.createElement('style');
        style.id = 'ripple-animation';
        style.textContent = `
          @keyframes nid_tab_ripple {
            to {
              transform: scale(100);
              opacity: 0;
            }
          }
        `;
        document.head.appendChild(style);
      }
    });
  </script>

    <style>
        /* Reset and base styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f4f4f4;
        }

        /* Footer styles */
        .footer {
            background: linear-gradient(135deg,rgb(7, 7, 7) 0%,rgb(42, 42, 43) 50%,rgb(60, 60, 60) 100%);
            color: #fff;
            padding: 60px 0 30px;
            width: 100%;
            position: relative;
            overflow: hidden;
        }

        .footer::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, #ff9966, #ff5e62, #ff5e62, #ff9966);
        }

        .container {
            max-width: 1300px;
            margin: 0 auto;
            padding: 0 20px;
            position: relative;
            z-index: 1;
        }

        .footer-title-container {
            text-align: center;
            margin-bottom: 40px;
            position: relative;
        }

        .footer-title {
            font-size: 32px;
            font-weight: 700;
            color: #fff;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 10px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
            position: relative;
            display: inline-block;
        }

        .footer-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background: linear-gradient(90deg, #ff9966, #ff5e62);
            border-radius: 3px;
        }

        .footer-subtitle {
            font-size: 14px;
            color: #ccc;
            margin-top: 15px;
        }

        .india-map-icon {
            width: 40px;
            height: 40px;
            margin-right: 10px;
            vertical-align: middle;
        }

        .footer-columns {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            margin-bottom: 40px;
        }

        .footer-column {
            flex: 1;
            min-width: 250px;
            padding: 0 15px;
            margin-bottom: 20px;
        }

        .location-block {
            margin-bottom: 25px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            padding: 15px;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }

        .location-block:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            background: rgba(255, 255, 255, 0.1);
            border-left: 3px solid #ff5e62;
        }

        .location-title {
            font-size: 14px;
            margin-bottom: 12px;
            color: #fff;
            font-weight: 600;
            display: flex;
            align-items: center;
        }

        .location-title::before {
            content: '\f3c5';
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
            margin-right: 8px;
            color: #ff5e62;
        }

        .location-list {
            list-style: none;
        }

        .location-list li {
            margin-bottom: 8px;
            font-size: 13px;
            display: flex;
            align-items: baseline;
            transition: transform 0.2s;
        }

        .location-list li:hover {
            transform: translateX(5px);
        }

        .location-list li::before {
            content: "•";
            color: #ff9966;
            display: inline-block;
            width: 10px;
            margin-right: 5px;
        }

        .direction-link {
            color: #66ccff;
            text-decoration: none;
            transition: all 0.3s;
            position: relative;
            padding-bottom: 2px;
        }

        .direction-link::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 1px;
            background-color: #66ccff;
            transition: width 0.3s;
        }

        .direction-link:hover {
            color: #fff;
        }

        .direction-link:hover::after {
            width: 100%;
        }

        /* Map preview */
        .map-preview {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 300px;
            height: 200px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            z-index: 1000;
            display: none;
            overflow: hidden;
        }

        .map-preview-header {
            background-color: #16213e;
            color: #fff;
            padding: 10px;
            font-size: 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .map-preview-close {
            cursor: pointer;
            font-size: 16px;
        }

        .map-preview-content {
            height: calc(100% - 40px);
            background-color: #f0f0f0;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #333;
            font-size: 12px;
            padding: 10px;
            text-align: center;
        }

        .map-preview-content img {
            max-width: 100%;
            max-height: 100%;
            object-fit: cover;
        }

        /* Footer bottom section */
        .footer-bottom {
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding-top: 30px;
            text-align: center;
        }

        .footer-links {
            margin-bottom: 20px;
            font-size: 12px;
            line-height: 2;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .footer-links a {
            color: #ccc;
            text-decoration: none;
            transition: color 0.3s;
            margin: 0 8px;
            position: relative;
        }

        .footer-links a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 1px;
            background-color: #fff;
            transition: width 0.3s;
        }

        .footer-links a:hover {
            color: #fff;
        }

        .footer-links a:hover::after {
            width: 100%;
        }

        .copyright {
            font-size: 13px;
            color: #999;
            margin-bottom: 20px;
        }

        .social-icons {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 20px;
        }

        .social-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
            border-radius: 50%;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }

        .social-icon::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, #ff9966, #ff5e62);
            opacity: 0;
            transition: opacity 0.3s;
            z-index: -1;
        }

        .social-icon:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(255, 94, 98, 0.4);
        }

        .social-icon:hover::before {
            opacity: 1;
        }

        /* Back to top button */
        .back-to-top {
            position: fixed;
            bottom: 100px;
            right: 40px;
            width: 50px;
            height: 50px;
            background: linear-gradient(45deg,rgb(245, 144, 146), rgb(199, 59, 61));
            color: #fff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
            z-index: 999;
            box-shadow: 0 5px 15px rgba(255, 94, 98, 0.4);
        }

        .back-to-top.visible {
            opacity: 1;
            visibility: visible;
        }

        .back-to-top:hover {
            transform: translateY(-5px);
        }

        /* Search box */
        .location-search {
            margin-bottom: 30px;
            display: flex;
            justify-content: center;
        }

        .search-container {
            position: relative;
            width: 100%;
            max-width: 500px;
        }

        .search-input {
            width: 100%;
            padding: 12px 20px;
            padding-left: 45px;
            border: none;
            border-radius: 30px;
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
            font-size: 14px;
            transition: all 0.3s;
            outline: none;
        }

        .search-input::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }

        .search-input:focus {
            background: rgba(255, 255, 255, 0.15);
            box-shadow: 0 0 15px rgba(255, 255, 255, 0.1);
        }

        .search-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.6);
        }

        /* Responsive styles */
        @media (max-width: 1200px) {
            .footer-column {
                flex: 0 0 50%;
            }
        }

        @media (max-width: 768px) {
            .footer {
                padding: 40px 0 20px;
            }
            
            .footer-column {
                flex: 0 0 100%;
            }
            
            .footer-title {
                font-size: 26px;
            }
            
            .location-block {
                padding: 12px;
            }
            
            .search-input {
                padding: 10px 15px 10px 40px;
            }
            
            .map-preview {
                width: 250px;
                height: 180px;
            }
        }

        @media (max-width: 480px) {
            .footer {
                padding: 30px 0 15px;
            }
            
            .footer-title {
                font-size: 22px;
            }
            
            .location-title {
                font-size: 13px;
            }
            
            .location-list li {
                font-size: 12px;
            }
            
            .footer-links {
                font-size: 11px;
            }
            
            .social-icon {
                width: 35px;
                height: 35px;
            }
            
            .map-preview {
                width: 200px;
                height: 150px;
                bottom: 10px;
                right: 10px;
            }
        }

        /* Animation keyframes */
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        /* Decorative elements */
        .decorative-circle {
            position: absolute;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, rgba(255, 255, 255, 0) 70%);
            z-index: 0;
        }

        .circle-1 {
            width: 300px;
            height: 300px;
            top: -150px;
            left: -150px;
        }

        .circle-2 {
            width: 400px;
            height: 400px;
            bottom: -200px;
            right: -200px;
        }

        .circle-3 {
            width: 200px;
            height: 200px;
            top: 30%;
            right: 10%;
        }
    </style>
</head>
<body>
    <footer class="footer">

        <div class="container">
            <div class="footer-title-container">
                <h2 class="footer-title">
                    BRDS CENTRES IN INDIA
                </h2>
                <p class="footer-subtitle">Find your nearest design education center</p>
            </div>

            <div class="location-search">
                <div class="search-container">
                    <i class="fas fa-search search-icon"></i>
                    <input type="text" class="search-input" placeholder="Search for a location..." id="locationSearch">
                </div>
            </div>
            
            <div class="footer-columns">
                <!-- Column 1 -->
                <div class="footer-column">
                    <div class="location-block" data-city="ahmedabad">
                        <h4 class="location-title">AHMEDABAD : 98250 57598</h4>
                        <ul class="location-list">
                            <li>Drive in Road <a href="#" class="direction-link" data-location="BRDS Drive in Road, Ahmedabad">( Get Direction )</a></li>
                            <li>Bopal <a href="#" class="direction-link" data-location="BRDS Bopal, Ahmedabad">( Get Direction )</a></li>
                            <li>Chandkheda <a href="#" class="direction-link" data-location="BRDS Chandkheda, Ahmedabad">( Get Direction )</a></li>
                            <li>Maninagar <a href="#" class="direction-link" data-location="BRDS Maninagar, Ahmedabad">( Get Direction )</a></li>
                            <li>Nikol <a href="#" class="direction-link" data-location="BRDS Nikol, Ahmedabad">( Get Direction )</a></li>
                            <li>Satellite <a href="#" class="direction-link" data-location="BRDS Satellite, Ahmedabad">( Get Direction )</a></li>
                            <li>Science City Road <a href="#" class="direction-link" data-location="BRDS Science City Road, Ahmedabad">( Get Direction )</a></li>
                        </ul>
                    </div>

                    <div class="location-block" data-city="vadodara">
                        <h4 class="location-title">VADODARA : 90998 57598</h4>
                        <ul class="location-list">
                            <li>Race Course Road <a href="#" class="direction-link" data-location="BRDS Race Course Road, Vadodara">( Get Direction )</a></li>
                        </ul>
                    </div>

                    <div class="location-block" data-city="rajkot">
                        <h4 class="location-title">RAJKOT : 90998 57598</h4>
                        <ul class="location-list">
                            <li>Kalawad Road <a href="#" class="direction-link" data-location="BRDS Kalawad Road, Rajkot">( Get Direction )</a></li>
                        </ul>
                    </div>

                    <div class="location-block" data-city="surat">
                        <h4 class="location-title">SURAT : 90998 57598</h4>
                        <ul class="location-list">
                            <li>Athwa <a href="#" class="direction-link" data-location="BRDS Athwa, Surat">( Get Direction )</a></li>
                        </ul>
                    </div>

                    <div class="location-block" data-city="kolkata">
                        <h4 class="location-title">KOLKATA : 75678 57598</h4>
                        <ul class="location-list">
                            <li>Middleton Street <a href="#" class="direction-link" data-location="BRDS Middleton Street, Kolkata">( Get Direction )</a></li>
                        </ul>
                    </div>

                    <div class="location-block" data-city="jaipur">
                        <h4 class="location-title">JAIPUR : 9727857598</h4>
                        <ul class="location-list">
                            <li>Gopalpura <a href="#" class="direction-link" data-location="BRDS Gopalpura, Jaipur">( Get Direction )</a></li>
                            <li>Vaishali Nagar <a href="#" class="direction-link" data-location="BRDS Vaishali Nagar, Jaipur">( Get Direction )</a></li>
                            <li>Malviya Nagar <a href="#" class="direction-link" data-location="BRDS Malviya Nagar, Jaipur">( Get Direction )</a></li>
                        </ul>
                    </div>
                </div>

                <!-- Column 2 -->
                <div class="footer-column">
                    <div class="location-block" data-city="delhi">
                        <h4 class="location-title">DELHI NCR : 99137 00910</h4>
                        <ul class="location-list">
                            <li>Malviya Nagar <a href="#" class="direction-link" data-location="BRDS Malviya Nagar, Delhi">( Get Direction )</a></li>
                            <li>Preet Vihar <a href="#" class="direction-link" data-location="BRDS Preet Vihar, Delhi">( Get Direction )</a></li>
                            <li>Pitampura <a href="#" class="direction-link" data-location="BRDS Pitampura, Delhi">( Get Direction )</a></li>
                            <li>Dwarka <a href="#" class="direction-link" data-location="BRDS Dwarka, Delhi">( Get Direction )</a></li>
                            <li>South Ex– 1 <a href="#" class="direction-link" data-location="BRDS South Ex-1, Delhi">( Get Direction )</a></li>
                            <li>Karol Bagh <a href="#" class="direction-link" data-location="BRDS Karol Bagh, Delhi">( Get Direction )</a></li>
                            <li>Janakpuri West <a href="#" class="direction-link" data-location="BRDS Janakpuri West, Delhi">( Get Direction )</a></li>
                        </ul>
                    </div>

                    <div class="location-block" data-city="chandigarh">
                        <h4 class="location-title">CHANDIGARH : 9727857598</h4>
                        <ul class="location-list">
                            <li>Sector 34-A <a href="#" class="direction-link" data-location="BRDS Sector 34-A, Chandigarh">( Get Direction )</a></li>
                        </ul>
                    </div>

                    <div class="location-block" data-city="lucknow">
                        <h4 class="location-title">LUCKNOW : 75749 57598</h4>
                        <ul class="location-list">
                            <li>Hazratganj <a href="#" class="direction-link" data-location="BRDS Hazratganj, Lucknow">( Get Direction )</a></li>
                            <li>Aliganj <a href="#" class="direction-link" data-location="BRDS Aliganj, Lucknow">( Get Direction )</a></li>
                        </ul>
                    </div>

                    <div class="location-block" data-city="bhopal">
                        <h4 class="location-title">BHOPAL : 9727857598</h4>
                        <ul class="location-list">
                            <li>M.P. Nagar <a href="#" class="direction-link" data-location="BRDS M.P. Nagar, Bhopal">( Get Direction )</a></li>
                        </ul>
                    </div>

                    <div class="location-block" data-city="raipur">
                        <h4 class="location-title">CHHATTISGARH : 9727857598</h4>
                        <ul class="location-list">
                            <li>Raipur <a href="#" class="direction-link" data-location="BRDS Raipur, Chhattisgarh">( Get Direction )</a></li>
                        </ul>
                    </div>
                </div>

                <!-- Column 3 -->
                <div class="footer-column">
                    <div class="location-block" data-city="mumbai">
                        <h4 class="location-title">MUMBAI : 75060 12398</h4>
                        <ul class="location-list">
                            <li>Andheri <a href="#" class="direction-link" data-location="BRDS Andheri, Mumbai">( Get Direction )</a></li>
                            <li>Bandra West <a href="#" class="direction-link" data-location="BRDS Bandra West, Mumbai">( Get Direction )</a></li>
                            <li>Borivali <a href="#" class="direction-link" data-location="BRDS Borivali, Mumbai">( Get Direction )</a></li>
                            <li>Charni Road <a href="#" class="direction-link" data-location="BRDS Charni Road, Mumbai">( Get Direction )</a></li>
                            <li>Dadar <a href="#" class="direction-link" data-location="BRDS Dadar, Mumbai">( Get Direction )</a></li>
                            <li>Ghatkopar <a href="#" class="direction-link" data-location="BRDS Ghatkopar, Mumbai">( Get Direction )</a></li>
                            <li>Thane <a href="#" class="direction-link" data-location="BRDS Thane, Mumbai">( Get Direction )</a></li>
                        </ul>
                    </div>

                    <div class="location-block" data-city="pune">
                        <h4 class="location-title">PUNE : 99786 57598</h4>
                        <ul class="location-list">
                            <li>M. G. Road <a href="#" class="direction-link" data-location="BRDS M.G. Road, Pune">( Get Direction )</a></li>
                            <li>Law College Road <a href="#" class="direction-link" data-location="BRDS Law College Road, Pune">( Get Direction )</a></li>
                            <li>Chinchwad <a href="#" class="direction-link" data-location="BRDS Chinchwad, Pune">( Get Direction )</a></li>
                            <li>Viman Nagar <a href="#" class="direction-link" data-location="BRDS Viman Nagar, Pune">( Get Direction )</a></li>
                            <li>Baner <a href="#" class="direction-link" data-location="BRDS Baner, Pune">( Get Direction )</a></li>
                        </ul>
                    </div>

                    <div class="location-block" data-city="nashik">
                        <h4 class="location-title">NASHIK : 95123 57598</h4>
                        <ul class="location-list">
                            <li>College Road <a href="#" class="direction-link" data-location="BRDS College Road, Nashik">( Get Direction )</a></li>
                        </ul>
                    </div>

                    <div class="location-block" data-city="nagpur">
                        <h4 class="location-title">NAGPUR : 95123 57598</h4>
                        <ul class="location-list">
                            <li>Dharampeth <a href="#" class="direction-link" data-location="BRDS Dharampeth, Nagpur">( Get Direction )</a></li>
                            <li>Ayodhya Nagar <a href="#" class="direction-link" data-location="BRDS Ayodhya Nagar, Nagpur">( Get Direction )</a></li>
                        </ul>
                    </div>
                </div>

                <!-- Column 4 -->
                <div class="footer-column">
                    <div class="location-block" data-city="kanpur">
                        <h4 class="location-title">KANPUR : 75749 57598</h4>
                        <ul class="location-list">
                            <li>Kakadeo <a href="#" class="direction-link" data-location="BRDS Kakadeo, Kanpur">( Get Direction )</a></li>
                            <li>Kidwai Nagar <a href="#" class="direction-link" data-location="BRDS Kidwai Nagar, Kanpur">( Get Direction )</a></li>
                        </ul>
                    </div>

                    <div class="location-block" data-city="varanasi">
                        <h4 class="location-title">VARANASI : 7574957598</h4>
                        <ul class="location-list">
                            <li>Durgakund <a href="#" class="direction-link" data-location="BRDS Durgakund, Varanasi">( Get Direction )</a></li>
                        </ul>
                    </div>

                    <div class="location-block" data-city="kerala">
                        <h4 class="location-title">KERALA : 89807 57598</h4>
                        <ul class="location-list">
                            <li>Calicut <a href="#" class="direction-link" data-location="BRDS Calicut, Kerala">( Get Direction )</a></li>
                            <li>Kochi <a href="#" class="direction-link" data-location="BRDS Kochi, Kerala">( Get Direction )</a></li>
                        </ul>
                    </div>

                    <div class="location-block" data-city="chennai">
                        <h4 class="location-title">CHENNAI : 89807 57598</h4>
                        <ul class="location-list">
                            <li>Anna Nagar West <a href="#" class="direction-link" data-location="BRDS Anna Nagar West, Chennai">( Get Direction )</a></li>
                        </ul>
                    </div>

                    <div class="location-block" data-city="hyderabad">
                        <h4 class="location-title">HYDERABAD : 89807 57598</h4>
                        <ul class="location-list">
                            <li>Himayatnagar <a href="#" class="direction-link" data-location="BRDS Himayatnagar, Hyderabad">( Get Direction )</a></li>
                            <li>Jubilee Hills <a href="#" class="direction-link" data-location="BRDS Jubilee Hills, Hyderabad">( Get Direction )</a></li>
                        </ul>
                    </div>

                    <div class="location-block" data-city="dubai">
                        <h4 class="location-title">DUBAI : +971582554313</h4>
                        <ul class="location-list">
                            <li>Dubai <a href="#" class="direction-link" data-location="BRDS Dubai">( Get Direction )</a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="footer-bottom">
                <div class="footer-links">
                    <a href="#">NID Coaching in Delhi</a>
                    <a href="#">NID Coaching in Mumbai</a>
                    <a href="#">NID Coaching in Pune</a>
                    <a href="#">NID Coaching in Kolkata</a>
                    <a href="#">NID Coaching in Ahmedabad</a>
                    <a href="#">NID Coaching in Vadodara</a>
                    <a href="#">NIFT</a>
                    <a href="#">NIFT Coaching in Delhi</a>
                    <a href="#">NIFT Coaching in Mumbai</a>
                    <a href="#">NIFT Coaching in Pune</a>
                    <a href="#">NIFT Coaching in Kolkata</a>
                    <a href="#">NIFT Coaching in Ahmedabad</a>
                    <a href="#">NIFT Coaching in Vadodara</a>
                    <a href="#">CEED Coaching in Delhi</a>
                    <a href="#">CEED Coaching in Mumbai</a>
                    <a href="#">CEED Coaching in Pune</a>
                </div>
            </div>
        </div>

        <!-- Map preview -->
        <div class="map-preview" id="mapPreview">
            <div class="map-preview-header">
                <span id="mapPreviewTitle">Location Preview</span>
                <span class="map-preview-close" id="mapPreviewClose">&times;</span>
            </div>
            <div class="map-preview-content" id="mapPreviewContent">
                <p>Hover over a location to see a preview</p>
            </div>
        </div>

        <!-- Back to top button -->
        <div class="back-to-top" id="backToTop">
            <i class="fas fa-arrow-up"></i>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Get all direction links
            const directionLinks = document.querySelectorAll('.direction-link');
            const mapPreview = document.getElementById('mapPreview');
            const mapPreviewTitle = document.getElementById('mapPreviewTitle');
            const mapPreviewContent = document.getElementById('mapPreviewContent');
            const mapPreviewClose = document.getElementById('mapPreviewClose');
            const backToTop = document.getElementById('backToTop');
            const searchInput = document.getElementById('locationSearch');
            const locationBlocks = document.querySelectorAll('.location-block');
            
            // Add click event listener to each direction link
            directionLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    // Prevent default behavior (opening link)
                    e.preventDefault();
                    
                    // Get the location from data attribute
                    const location = this.getAttribute('data-location');
                    
                    // In a real implementation, you would redirect to Google Maps
                    const googleMapsUrl = `https://www.google.com/maps/search/${encodeURIComponent(location)}`;
                    window.open(googleMapsUrl, '_blank');
                });
                
                // Add hover event for map preview
                link.addEventListener('mouseenter', function() {
                    const location = this.getAttribute('data-location');
                    showMapPreview(location);
                });
            });
            
            // Function to show map preview
            function showMapPreview(location) {
                mapPreviewTitle.textContent = location;
                
                // In a real implementation, you would load an actual map preview
                // For this demo, we'll just show a placeholder
                mapPreviewContent.innerHTML = `
                    <div style="text-align: center;">
                        <i class="fas fa-map-marker-alt" style="font-size: 24px; color: #ff5e62; margin-bottom: 10px;"></i>
                        <p>${location}</p>
                        <p style="font-size: 10px; margin-top: 5px;">Click "Get Direction" for full map</p>
                    </div>
                `;
                
                mapPreview.style.display = 'block';
            }
            
            // Close map preview
            mapPreviewClose.addEventListener('click', function() {
                mapPreview.style.display = 'none';
            });
            
            // Back to top functionality
            window.addEventListener('scroll', function() {
                if (window.pageYOffset > 300) {
                    backToTop.classList.add('visible');
                } else {
                    backToTop.classList.remove('visible');
                }
            });
            
            backToTop.addEventListener('click', function() {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });
            
            // Search functionality
            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                
                locationBlocks.forEach(block => {
                    const city = block.getAttribute('data-city').toLowerCase();
                    const locationText = block.textContent.toLowerCase();
                    
                    if (city.includes(searchTerm) || locationText.includes(searchTerm)) {
                        block.style.display = 'block';
                        // Highlight the block if it's an exact match
                        if (city === searchTerm) {
                            block.style.borderLeft = '3px solid #ff5e62';
                            block.style.transform = 'translateY(-5px)';
                            block.style.boxShadow = '0 10px 20px rgba(0, 0, 0, 0.2)';
                            block.style.background = 'rgba(255, 255, 255, 0.1)';
                        }
                    } else {
                        block.style.display = 'none';
                    }
                });
                
                // Reset styles if search is cleared
                if (searchTerm === '') {
                    locationBlocks.forEach(block => {
                        block.style.display = 'block';
                        block.style.borderLeft = '3px solid transparent';
                        block.style.transform = 'translateY(0)';
                        block.style.boxShadow = 'none';
                        block.style.background = 'rgba(255, 255, 255, 0.05)';
                    });
                }
            });
            
            // Add hover effects for location blocks
            locationBlocks.forEach(block => {
                block.addEventListener('mouseenter', function() {
                    if (searchInput.value === '') {
                        this.style.transform = 'translateY(-5px)';
                        this.style.boxShadow = '0 10px 20px rgba(0, 0, 0, 0.2)';
                        this.style.background = 'rgba(255, 255, 255, 0.1)';
                        this.style.borderLeft = '3px solid #ff5e62';
                    }
                });
                
                block.addEventListener('mouseleave', function() {
                    if (searchInput.value === '') {
                        this.style.transform = 'translateY(0)';
                        this.style.boxShadow = 'none';
                        this.style.background = 'rgba(255, 255, 255, 0.05)';
                        this.style.borderLeft = '3px solid transparent';
                    }
                });
            });
            
            // Make footer title clickable
            const footerTitle = document.querySelector('.footer-title');
            footerTitle.style.cursor = 'pointer';
            footerTitle.addEventListener('click', function() {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });
            
            // Add animation to the title
            footerTitle.style.animation = 'pulse 2s infinite';
        });
    </script>
   
    <div class="copyright_sec pt-3 pb-3">
        <div class="container">
            <div class="row text-center">
                <h6 class="mb-0">Copyright © BRDS 2025. All Rights <a href="https://www.thedesignvillage.org/course/communication-design-courses-and-interaction-design-courses/" style="cursor: default; color: inherit; text-decoration: none;">Reserved | <a href="https://blog.nidcoaching.org/">Blog</a> | <a href="https://www.facebook.com/rathoredesign"><i class="fa-brands fa-square-facebook"></i></a> | <a href="https://www.instagram.com/brds_india/"><i class="fa-brands fa-instagram"></i></a> | <a href="https://twitter.com/bhanwarbrds"><i class="fa-brands fa-x-twitter"></i></a> | <a href="https://www.youtube.com/c/rathoredesignstudio"><i class="fa-brands fa-youtube"></i></a></h6>
            </div>
        </div>
    </div>
    <div class="call-button-wrapper">
        <a href="tel:+919825057598" class="call-button">
            <i class="fas fa-phone"></i>
            <span>Call Us</span>
        </a>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/js/splide.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            new Splide('.splide', {
                type: 'loop',
                perPage: 1,
                autoplay: true,
            }).mount();

            // Form validation
            const form = document.getElementById('brds_form');
            form.addEventListener('submit', function(event) {
                event.preventDefault();
            });
        });
    </script>
   
<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('brds_form');
    
    // Cache DOM elements
    const submitButton = form.querySelector('input[type="submit"]');
    const nameInput = document.getElementById('name');
    const phoneInput = document.getElementById('phone_number');
    const emailInput = document.getElementById('email');

    // Form validation and submission
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        
        // Validate form
        if (!validateForm()) {
            return false;
        }
        
        // Show loading state
        submitButton.value = 'Submitting...';
        submitButton.disabled = true;
        
        // Create a loading overlay
        const loadingOverlay = document.createElement('div');
        loadingOverlay.id = 'loading-overlay';
        loadingOverlay.innerHTML = '<div class="spinner"></div><p>Submitting your application...</p>';
        loadingOverlay.style.position = 'fixed';
        loadingOverlay.style.top = '0';
        loadingOverlay.style.left = '0';
        loadingOverlay.style.width = '100%';
        loadingOverlay.style.height = '100%';
        loadingOverlay.style.backgroundColor = 'rgba(255, 255, 255, 0.8)';
        loadingOverlay.style.display = 'flex';
        loadingOverlay.style.flexDirection = 'column';
        loadingOverlay.style.justifyContent = 'center';
        loadingOverlay.style.alignItems = 'center';
        loadingOverlay.style.zIndex = '9999';
        
        const spinner = document.createElement('div');
        spinner.style.border = '4px solid #f3f3f3';
        spinner.style.borderTop = '4px solid #e31e24';
        spinner.style.borderRadius = '50%';
        spinner.style.width = '40px';
        spinner.style.height = '40px';
        spinner.style.animation = 'spin 1s linear infinite';
        spinner.style.marginBottom = '15px';
        
        const style = document.createElement('style');
        style.textContent = '@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }';
        document.head.appendChild(style);
        
        loadingOverlay.appendChild(spinner);
        document.body.appendChild(loadingOverlay);
        
        // CRITICAL: Create a copy of the form data before submitting
        const formData = new FormData(form);
        
        // IMPORTANT: Redirect immediately after a very short delay
        // This is the key change - we redirect before even starting the fetch
        setTimeout(function() {
            window.location.href = 'thankyou.php';
        }, 800); // Short delay for visual feedback
        
        // Send the form data in the background after setting up the redirect
        // This will continue even after the page starts to navigate away
        setTimeout(function() {
            fetch('brds_crm_api.php', {
                method: 'POST',
                body: formData,
                // No need to wait for response
            });
        }, 100);
        
        return false;
    });

    // Form validation function
    function validateForm() {
        // Name validation
        if (!/^[A-Za-z\s]{2,50}$/.test(nameInput.value.trim())) {
            alert('Please enter a valid name (2-50 characters, letters and spaces only)');
            nameInput.focus();
            return false;
        }
        
        // Phone validation
        if (!/^[6-9]\d{9}$/.test(phoneInput.value)) {
            alert('Please enter a valid 10-digit phone number starting with 6-9');
            phoneInput.focus();
            return false;
        }
        
        // Email validation
        const emailPattern = /^[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!emailPattern.test(emailInput.value)) {
            alert('Please enter a valid email address');
            emailInput.focus();
            return false;
        }

        return true;
    }

    // Input event listeners
    nameInput.addEventListener('input', function(e) {
        this.value = this.value.replace(/[^A-Za-z\s]/g, '');
    });
    
    phoneInput.addEventListener('input', function(e) {
        this.value = this.value.replace(/[^0-9]/g, '');
        if (this.value.length === 1 && !['6','7','8','9'].includes(this.value)) {
            this.value = '';
        }
    });
});
</script>
<script>
function select_state_func() {
    const stateId = document.getElementById('stateid').value;
    const cityDropdown = document.getElementById('cityid');
    
    // Clear existing options
    cityDropdown.innerHTML = '<option value="">Your City</option>';
    
    // Define cities for each state
    const citiesByState = {
        '1': ['Port Blair'], // Andaman & Nicobar Islands
        '2': ['Visakhapatnam', 'Vijayawada', 'Guntur', 'Nellore', 'Kurnool', 'Rajahmundry', 'Tirupati'], // Andhra Pradesh
        '3': ['Itanagar', 'Naharlagun'], // Arunachal Pradesh
        '4': ['Guwahati', 'Silchar', 'Dibrugarh', 'Jorhat', 'Nagaon'], // Assam
        '5': ['Patna', 'Gaya', 'Bhagalpur', 'Muzaffarpur', 'Darbhanga'], // Bihar
        '6': ['Chandigarh'], // Chandigarh
        '7': ['Raipur', 'Bhilai', 'Bilaspur', 'Korba'], // Chhattisgarh
        '32': ['Silvassa'], // Dadra and Nagar Haveli
        '33': ['Daman', 'Diu'], // Daman and Diu
        '8': ['New Delhi', 'North Delhi', 'South Delhi', 'East Delhi', 'West Delhi'], // Delhi
        '9': ['Panaji', 'Margao', 'Vasco da Gama', 'Mapusa'], // Goa
        '10': ['Ahmedabad', 'Surat', 'Vadodara', 'Rajkot', 'Bhavnagar', 'Jamnagar', 'Gandhinagar'], // Gujarat
        '11': ['Faridabad', 'Gurugram', 'Nuh', 'Rohtak', 'Sonepat', 'Rewari', 'Jhajjar', 'Panipat', 'Palwal', 'Bhiwani', 'Charkhi Dadri', 'Mahendragarh', 'Jind', 'Karnal'], // Haryana
        '12': ['Shimla', 'Manali', 'Dharamshala', 'Kullu', 'Mandi'], // Himachal Pradesh
        '13': ['Srinagar', 'Jammu', 'Leh', 'Ladakh'], // Jammu and Kashmir
        '14': ['Ranchi', 'Jamshedpur', 'Dhanbad', 'Bokaro', 'Hazaribagh'], // Jharkhand
        '15': ['Bangalore', 'Mysore', 'Hubli', 'Mangalore', 'Belgaum'], // Karnataka
        '16': ['Thiruvananthapuram', 'Kochi', 'Kozhikode', 'Thrissur', 'Kollam'], // Kerala
        '17': ['Bhopal', 'Indore', 'Jabalpur', 'Gwalior', 'Ujjain'], // Madhya Pradesh
        '18': ['Mumbai', 'Pune', 'Nagpur', 'Thane', 'Nashik', 'Aurangabad'], // Maharashtra
        '19': ['Imphal'], // Manipur
        '20': ['Shillong'], // Meghalaya
        '21': ['Aizawl'], // Mizoram
        '22': ['Kohima', 'Dimapur'], // Nagaland
        '23': ['Bhubaneswar', 'Cuttack', 'Rourkela', 'Puri'], // Orissa
        '24': ['Puducherry'], // Pondicherry
        '25': ['Chandigarh', 'Ludhiana', 'Amritsar', 'Jalandhar', 'Patiala'], // Punjab
        '26': ['Jaipur', 'Jodhpur', 'Udaipur', 'Kota', 'Ajmer', 'Bikaner'], // Rajasthan
        '34': ['Gangtok'], // Sikkim
        '27': ['Chennai', 'Coimbatore', 'Madurai', 'Salem', 'Tiruchirappalli'], // Tamil Nadu
        '36': ['Hyderabad', 'Warangal', 'Nizamabad', 'Karimnagar'], // Telangana
        '28': ['Agartala'], // Tripura
        '29': ['Noida', 'Greater Noida', 'Ghaziabad', 'Meerut'], // Uttar Pradesh
        '30': ['Dehradun', 'Haridwar', 'Roorkee', 'Nainital'], // Uttaranchal
        '31': ['Kolkata', 'Howrah', 'Durgapur', 'Asansol', 'Siliguri'] // West Bengal
    };

    // Add cities for selected state
    if (citiesByState[stateId]) {
        citiesByState[stateId].forEach(city => {
            const option = document.createElement('option');
            option.value = city;
            option.textContent = city;
            cityDropdown.appendChild(option);
        });
    }
}

// Call the function when page loads if state is pre-selected
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('stateid').value) {
        select_state_func();
    }
});
</script>
    </body>
</html>
